(* Mathematica Init File *)

Get[ "IdentifiabilityAnalysis`IdentifiabilityAnalysis`"]