(* Paclet Info File *)

(* created 2012/07/03*)

Paclet[
    Name -> "IdentifiabilityAnalysis",
    Version -> "0.9.0",
    MathematicaVersion -> "6+",
    Creator -> "Fraunhofer-Chalmers Centre",
    Extensions -> 
        {
            {"Documentation", Resources -> 
                {"Guides/IdentifiabilityAnalysis"}
            , Language -> "English"}
        }
]


