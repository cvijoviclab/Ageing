%% Tetragon of Ageing: Generate the parameters space
% Date: 2019-02-14
% Written by: Johannes Borgqvist
% Description: 
% The program generates the plot of the parameter space which we use. 
%% (0.) Setting up everything
% Tidy up to get a nice work space
clear,clc;
%-----------------------------------------------------------
% We have the setup variables stored in the variable 
% called "GeneralData.mat". So, we load it!
data = load('GeneralData.mat');
% We save the division threshold, Pdiv
Pdiv = data.Pdiv;
% We save the resilience quotient, Q
% We have three cases: low, medium and high
 Q = round(data.Q,1);
%Q = data.Q;
% We save the size proportion, s
s = round(data.sAvg,2);
% Now, we calculate the retention coefficient with our magic formula
% Retention coefficient 
re = ( 1 / Q ) * ( ( ( 2 * s ) - 1 ) / ( 1 - s ) );
% We take the growth factor g
g = 1.1;

%% Define thee looping
% Damage resilience matrix.
QVec = [2.6; 2.6; 2.6; 3; 3; 3];
% Retention vector
reVec = [ ( ((2*s) - 1 ) /  (QVec(1)*(1-s)) ); 0; 0; 0; 0; ( ((2*s) - 1 ) /  (QVec(6)*(1-s)) )];
% Size proprotion vector
sVec = [s; s; 0.5; 0.5; s; s];
% Define number of element
nuOfIter = length(sVec);

 delta = 0.0001; % delta variable for the cyclic updating
%delta = 0.000001; % delta variable for the cyclic updating
P0Value = s - (re * Q * (1-s)); % Define the starting point for the mother
P0First = flip((P0Value:delta:(1-delta))'); % Define a vector for the upper bound
P0Second = flip(((1-s):delta:(1-delta))'); % Define a vector for the lower bound
upperBound = s + (re * (1-s)); % The upper bound for the immortality constraint
% We also define a delta value for the parameters in which the
% approximation is not reliable
paramDelta = 0.6;
%% DEFINE THE PARAMETER VALUES AND ALLOCATE MEMORY FOR THE THRESHOLD
nuOfEle = 300;
%k1Vec = linspace(0.001,g,nuOfEle);
k1Vec = linspace(0.2,g,nuOfEle);
%k2Vec = flip(linspace(0.001,g,nuOfEle)');
k2Vec = flip(linspace(0.001,g,nuOfEle)');
%triangle = fopen(['triangleRe',num2str(1000*re),'.dat'],'w');


% Loop over the experimental design, hey?
for i=1:nuOfIter
    % The damage resilience
    Q = QVec(i);
    %The retention re
    re = reVec(i);
    % The size proportion, s
    s = sVec(i);
    
    fprintf('ATTEMPT %d\n\n',i);
    
    triangle = fopen(['./data_Q_',num2str(round(10*Q)),'_re_',num2str(round(re,3)*1000),'_s_',num2str(round(s*100)),'.dat'],'w');
    
    %% Calculate the death thresholds
    % Print a welcoming message to the user
    % Loop through all parameters hey?
    fprintf('\n==========================================================================================\n\n');
    fprintf('\tWe calculate the RLS over the parameter space within the triangle of ageing!\n\n');
    fprintf('\t\tQ=%0.3f\ts=%0.2f\tre=%0.3f\n\n',Q,s,re);
    fprintf('\n-------------------------------------------------------------------------------------------\n\n');
    % We benchmark this as well to have some idea of time
    tStart = tic;
    % Loop through all parameters hey?
    for cI = 1:nuOfEle
        % We define the repair rate constant
        k2 = k2Vec(cI); % k2
        % We define the value for the border of k1 where the
        % approximation gets not reliable
        %borderValuek1 = (mu * (g - 1)) + (k2 * Q);
        borderValuek1 = (g - 1) + (k2 * Q);
        % print the column for the user
        %fprintf('\tIndex %d out of %d\n',cI,nuOfEle);
        for rI = 1:nuOfEle
            %% Define parameters and calculate constants
            % Temporary parameters
            k1 = k1Vec(rI); % k1
            %% DO THE IF STATEMENTS
            % Check the starvation condition
            if (g < (k1+k2))
                continue;
                % Now we know that the threshold approximations for certain k1
                % values are not valid so we solve for these parameters just in
                % case we might miss something
            elseif (k1 > (borderValuek1 - paramDelta)) && (k1 < (borderValuek1 + paramDelta))
                %--------------------------------------------------------------
                % Simulate the RLS hey
                %--------------------------------------------------------------
                %[RLS,generationTime] = generationCounter(mu,g,k1,k2,Q,re,dynInd,s);
                [RLS,generationTime] = generationCounter(g,k1,k2,Q,re,s);
                %--------------------------------------------------------------
                % We do use approximations so throw away immortal cells
                %--------------------------------------------------------------
                if (RLS < 600) && (RLS > 0)
                    %--------------------------------------------------------------
                    % We save the parameters along with the RLS
                    %--------------------------------------------------------------
                    fprintf(triangle,'%0.5f\t%0.5f\t%1.5f\n',k1,k2,log10(RLS));
                end
            else % Within the triangle: check immortality and clonal senescence
                %--------------------------------------------------------------
                % Immortality constraint
                %--------------------------------------------------------------
                %DTmother = damageThreshold(mu,k1,k2,Q,g,1,1,P0First);
                DTmother = damageThreshold(k1,k2,Q,g,1,1,P0First);
                %--------------------------------------------------------------
                % Clonal senescence constraint
                %--------------------------------------------------------------
                %DTdaughter = damageThreshold(mu,k1,k2,Q,g,1,1,P0Second);
                DTdaughter = damageThreshold(k1,k2,Q,g,1,1,P0Second);
                %--------------------------------------------------------------
                % Are the immortality and clonal senescence constraints satisfied?
                %--------------------------------------------------------------
                if (DTmother < upperBound) && (DTdaughter > 0)
                    %--------------------------------------------------------------
                    % Simulate the RLS hey
                    %--------------------------------------------------------------
                    %[RLS,generationTime] = generationCounter(mu,g,k1,k2,Q,re,dynInd,s);
                    [RLS,generationTime] = generationCounter(g,k1,k2,Q,re,s);
                    %--------------------------------------------------------------
                    % We do use approximations so throw away immortal cells
                    %--------------------------------------------------------------
                    if (RLS < 600) && (RLS > 0)
                        %--------------------------------------------------------------
                        % We save the parameters along with the RLS
                        %--------------------------------------------------------------
                        fprintf(triangle,'%0.5f\t%0.5f\t%1.5f\n',k1,k2,log10(RLS));
                    end
                end
                % End starvation constraint
            end
            % End k1 loop
        end
        % End k2 loop
    end
    % We stop the benchmarking and print it
    tEnd = toc(tStart);
    minutes = floor(tEnd/60);
    seconds = floor(tEnd - (minutes*60));
    fprintf('\t\tIt took %d\tminutes and\t%d\tseconds!\n',minutes,seconds);
    % We print the finishing message
    fprintf('\n-------------------------------------------------------------------------------------------\n\n');
    fprintf('\tWe finish!\n\n')
    fprintf('\n==========================================================================================\n\n');
    
    % Close the file hey?
    fclose(triangle);
    
end



