function [P0,D0] = cellDivision(s,re,dynInd,DamOrg,Q,generationIndicator)
%% Constants for DC
% Date: 2018-03-13
% Written by: Johannes Borgqvist
% Description:
% Given the size proportion s, the retention coefficient
% re, the dynInd variable (1 for dynamic & 0 for static)
% the resilience parameter Q and the generationIndicator
%(1 for daughter & 0 for mother) the function returns
% the initial conditions [P0,D0].
%% Initial conditions
%----------------------------------------------------------
% Check the two cases: dynamic and static retention
if dynInd == 1 % Dynamic retention
    % We use the dynamic retention profile
    if (DamOrg<re)
        retention = 1;
    else
        frac1 = ((1)/(1-re));
        frac2 = ((1)/(1-DamOrg));
        retention = exp(frac1-frac2);
    end
else% Static retention
    retention = re;
end
%----------------------------------------------------------
% Initialise the intact and damage hey?
% We have a daughter cell
if generationIndicator == 1;
    P0 = (1-s)+retention*(1-s)*Q*DamOrg;% Intact daughter
    D0 = (1-s)*(1-retention)*DamOrg; % Intact mother
else % For the rest of her life, she is a mother...
    P0 = s - retention*(1-s)*Q*DamOrg; % Intact mother
    D0 = (s + ((1-s)*retention))*DamOrg; % Damage mother
end
end