function dydt = damageAccumulation(t,y,k,mu,g,Q)
%% Actual ODE solving
dydt = zeros(2,1);
dydt(1) = (mu * y(1) * (g - y(2))) - (k(1) * y(1)) + (k(2)*Q*y(2)); 
dydt(2) = ((k(1)/Q)*y(1)) - (k(2)*y(2));
end