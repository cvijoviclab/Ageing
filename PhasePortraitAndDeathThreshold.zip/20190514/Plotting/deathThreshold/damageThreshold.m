function DT = damageThreshold(mu,k1,k2,Q,g,Pstart,Dstart,Pnew)
P0 = Pstart;
D0 = Dstart;
for index = 1:length(Pnew)
    PT = Pnew(index);
    num = ((k1/Q)*P0) - (k2*D0);
    denom = (mu*P0*(g-D0)) - (k1*P0) + (k2*Q*D0);
    DT = D0 + (((num)/(denom))*(PT-P0));
    P0 = PT;
    D0 = DT;
end
end