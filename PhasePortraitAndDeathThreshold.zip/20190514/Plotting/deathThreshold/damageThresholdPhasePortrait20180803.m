%% DEFINE INITIAL PARAMETERS
clear,clc;
s = 3/4;% size proportion
Q = 1/3; % Ddeath/Pdiv
Ks = 2/3; % Monod constant
S = 1; % Substrate concentration
mu = ((S)/(S + Ks)); % Growth term
g = 1.4; % Growth factor
re = 0.4; % Retention coefficient  
dynInd = 0; % Static retention


P0Value = s - (re * Q * (1-s));
P0daughter = (1 - s);

k1 = 0.18;
k2 = 0.15;
%k1 = mu*(g-1) + (k2*Q);

P = []; 
D = [];
%%


delta = 0.0001;
P0Vec = P0daughter:delta:(1-delta);

for index = 1:length(P0Vec)
    P0 = P0Vec(index);
    Pnew = flip((P0:delta:1)');
    DTtemp = damageThreshold(mu,k1,k2,Q,g,1,1,Pnew);
    P = [P;P0];
    D = [D;DTtemp];    
end


[RLS,generationTime] = generationCounter(mu,g,k1,k2,Q,re,dynInd,s);



P0First = flip((P0Value:delta:(1-delta))'); % Define a vector for the upper bound
P0Second = flip(((1-s):delta:(1-delta))'); % Define a vector for the lower bound



%--------------------------------------------------------------
% Immortality constraint
%--------------------------------------------------------------
DTmother = damageThreshold(mu,k1,k2,Q,g,1,1,P0First);
%--------------------------------------------------------------
% Clonal senescence constraint
%--------------------------------------------------------------
DTdaughter = damageThreshold(mu,k1,k2,Q,g,1,1,P0Second);
% Upper bound hey?
upperBound = s + (re * (1-s)); % The upper bound for the immortality constraint

fprintf('\tDTm\tDTd\tupper\n\n\t%0.3f\t%0.3f\t%0.3f\n\n',DTmother,DTdaughter,upperBound);


%%

figure(1)
clf
plot(P,D,'Linewidth',2)
hold on
plot([0,1],[1,1],'--black','Linewidth',5)
hold on
plot([1,1],[0,1],'--black','Linewidth',5)
hold on 
plot([0,1],[(s + ((1-s)*re)),(s + ((1-s)*re))],'--magenta','Linewidth',5)
hold on 
plot([P0Value, P0Value],[0, 1],'-red','Linewidth',5)
hold on 
plot([P0daughter, P0daughter],[0, 1],'-cyan','Linewidth',5)
grid on
axis([0,1.1,0,1.1])
set(gca,'Ticklabelinterpreter','latex','Fontsize',30)
if RLS <600
    title({['$k_{1}=',num2str(k1),',\;\;\;k_{2}=',num2str(k2),',$'],['$\mathrm{re}=',num2str(re),'\;\;\;$\&$\;\;\;s=',num2str(s),'$'],['Numerical simulation$\Longrightarrow\mathrm{RLS}=',num2str(RLS),'$']},'interpreter','latex','Fontsize',70)
else
    title({['$k_{1}=',num2str(k1),',\;\;\;k_{2}=',num2str(k2),',$'],['$\mathrm{re}=',num2str(re),'\;\;\;$\&$\;\;\;s=',num2str(s),'$'],'Numerical simulation$\Longrightarrow\mathrm{RLS}=\infty$'},'interpreter','latex','Fontsize',70)    
end
xlabel('$P$','interpreter','latex','fontsize',40)
ylabel('$D$','interpreter','latex','fontsize',40)



nuOfEle = length(P);


%% ---------------------------------------------------
%= Old stuff with the phase portrait from before
%%---------------------------------------------------

% In order to have accuracy we generate
% a hell of a lot of approximations. So we take 
% ''älgkliv'' over this vector because there are
% too many elements in the vector at hand
stepSize = floor(nuOfEle/30);

fID = fopen('damageThreshold.txt','w');
    
str = '\addplot[forget plot,->,color=black] coordinates {';

for index= 1:stepSize:nuOfEle-stepSize
    fprintf(fID,'%s\n',str);
    fprintf(fID,'\t\t(%0.4f\t,\t%0.4f\t)\n',P(index,1),D(index,1));
    fprintf(fID,'\t\t(%0.4f\t,\t%0.4f\t)\n',P((index+stepSize),1),D((index + stepSize),1));
    fprintf(fID,'};\n\n');
end

strNew = '\addplot[->,color=black] coordinates {';
fprintf(fID,'%s\n',strNew);
fprintf(fID,'\t\t(%0.4f\t,\t%0.4f\t)\n',P((nuOfEle-stepSize),1),D((nuOfEle-stepSize),1));
fprintf(fID,'\t\t(%0.4f\t,\t%0.4f\t)\n',P(nuOfEle,1),D(nuOfEle,1));
fprintf(fID,'};');

fclose(fID);
    

    
    
    
    

