function [time, P, D] = homeMadeInterpolator(t,y)

[r,c] = size(y);
placeOfInterest = 0;
delta = 0;


for index = 1:r-1
    if (y(index,1) < 1) && (y(index+1,1) >= 1)
        placeOfInterest = index;
        break;
    elseif y(index,2) > 1
        time = t(index);
        P = y(index,1);
        D = y(index,2);
        return;
    end
end

if placeOfInterest == 0
    time = [0; 1];
    P = [0; 1];
    D = [0; -1];
else
    
    % Allocate memory for our guys
    time = zeros(placeOfInterest+1,1);
    P = zeros(placeOfInterest+1,1);
    D = zeros(placeOfInterest+1,1);
    % Assign values
    time(1:placeOfInterest) = t(1:placeOfInterest);
    P(1:placeOfInterest) = y(1:placeOfInterest,1);
    D(1:placeOfInterest) = y(1:placeOfInterest,2);
    
    
    delta = ((1-y(placeOfInterest,1))/(y((placeOfInterest+1),1) - y(placeOfInterest,1)));
    
    time(placeOfInterest + 1) = t(placeOfInterest) + delta*(t(placeOfInterest + 1) - t(placeOfInterest));
    D(placeOfInterest + 1) = y(placeOfInterest,2) + delta*(y((placeOfInterest + 1),2) - y(placeOfInterest,2));
    P(placeOfInterest + 1) = 1;
    
end


end