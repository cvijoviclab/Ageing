%% %% Tetragon of Ageing: Parameter Estimation
% Date: 2019-02-14
% Written by: Johannes Borgqvist
% Description: 
% We generate the various trajectories and save them in tex
% files so that we can generate a nice figure with pgfplot in
% LaTeX

%% (0.) Setting up everything
% Tidy up to get a nice work space
clear,clc;
%-----------------------------------------------------------
% We have the setup variables stored in the variable 
% called "GeneralData.mat". So, we load it!
data = load('GeneralData.mat');
% We save the division threshold, Pdiv
Pdiv = data.Pdiv;
% We save the resilience quotient, Q
% We have three cases: low, medium and high
Q = data.Q;
%Q = 1/3;
% We save the size proportion, s
s = data.sAvg;
%s = round(data.sAvg,2);
% Now, we calculate the retention coefficient with our magic formula
% Retention coefficient 
re = ( 1 / Q ) * ( ( ( 2 * s ) - 1 ) / ( 1 - s ) );
% We take the growth factor g
g = 2;
% Damge formation 
k1 = 0.5;
% Damage repair
%k2 = 0.15;
k2 = ((k1)/(2*g*Q))
% Damage formation and repair in ONE vector
k = [k1; k2];
%%


% Define the time span for the ODE
tspan = [0 100];

nuOfTrajectories = 4;
cellType = [1; 1; 0; 1];
D0Vec = [0; 0.8; 0; 0.4];
P0Vec = [1-s; 1-s; s; s];
for i = 1:nuOfTrajectories
    P0 = P0Vec(i);
    D0 = D0Vec(i);
    % Gather Initial conditions in a vector "y0"
    y0 = [P0; D0];
    % Solve the ODE with the given parameters and initial conditions
    [t,y] = ode45(@(t,y) damageAccumulation(t,y,k,g,Q), tspan, y0);        
    %% We print it to a tex file which we include in the plot laters...
    fileID = fopen(['./Plotting/Trajectory_',num2str(i),'.tex'],'w');
    str = '\addplot[forget plot,->,color=black] coordinates {';
    nuOfEle = length(t);
    for index= 1:nuOfEle-1
        fprintf(fileID,'%s\n',str);
        fprintf(fileID,'\t\t(%0.4f\t,\t%0.4f\t)\n',y(index,1),y(index,2));
        fprintf(fileID,'\t\t(%0.4f\t,\t%0.4f\t)\n',y(index+1,1),y(index+1,2));
        fprintf(fileID,'};');
    end
    
    fclose(fileID);    
    
end


