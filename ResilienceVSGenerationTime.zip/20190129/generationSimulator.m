%% %% Tetragon of Ageing: Parameter Estimation
% Date: 2019-01-29
% Written by: Johannes Borgqvist
% Description: 
% The program simulates the RLS with the given rate parameters
% and saves the files into text files so that we can plot them
% nicely in latex later.

%% (0.) Setting up everything
% Tidy up to get a nice work space
clear,clc;
%-----------------------------------------------------------
% We have the setup variables stored in the variable 
% called "GeneralData.mat". So, we load it!
data = load('GeneralData.mat');
% We save the division threshold, Pdiv
Pdiv = data.Pdiv;
% We save the resilience quotient, Q
% We have three cases: low, medium and high
%Q = data.Q;
%Q = round(data.Q,1);
Q = 2.6; % Low level
%Q = 2.8; % Medium level
%Q = 3.0; % High level
% We save the size proportion, s
%s = data.sAvg;
s = round(data.sAvg,2);
% Now, we calculate the retention coefficient with our magic formula
% Retention coefficient 
re = ( 1 / Q ) * ( ( ( 2 * s ) - 1 ) / ( 1 - s ) );
% We take the growth factor g
g = 1.1;

%% Some cool stuff with parameters and saving files
% OPEN ''.txt'' FILES FOR GENERATING NICE
% PGFPLOTS FIGURES FOR PUBLICATION
%intactFile = fopen('P_LaTeX.txt','w');% INTACT PROTEINS
%damageFile = fopen('D_LaTeX.txt','w');% DAMAGE
%intactFile = fopen('P.txt','w');% INTACT PROTEINS
%damageFile = fopen('D.txt','w');% DAMAGE
intactFile = fopen('P.txt','w');% INTACT PROTEINS
damageFile = fopen('D.txt','w');% DAMAGE

% PRINT THE FIRST TWO LINES
fprintf(intactFile,'t\tP\n');
fprintf(damageFile,'t\tD\n');

% We put an integer when we do not want to solve the ODEs anymore
infiniteGenerations = 500;
% Time span for the ODE solver
tspan = [0 100];
% We start as a daughter
generationIndicator = 1;

tTot = 0;
tTemp = 0;

blanks(5);
k1 = input('What is the damage formation rate, k1?\n');
blanks(5);
k2 = input('What is the damage repair rate, k2?\n');
k = [k1; k2];
y0 = [1-s,  0];


%% Start the plotting


figure(1)
clf
%fig = figure('units','normalized','outerposition',[0 0 1 1],...
%    'PaperPositionMode','auto');

[t,y] = ode45(@(t,y) odefcn(t,y,k,g,Q), tspan, y0);
n = length(t);


[time, P, D] = homeMadeInterpolator(t,y);
%%


damageValue = D(end);
if damageValue >0
    %damageThreshold = s*damageValue;
    
    tTot = tTot + time(end);
    
    %s,re,DamOrg,Q,generationIndicator
    [P0,D0] = cellDivision(s,re,damageValue,Q,generationIndicator);
    
    % From now on we are a mother cell
    generationIndicator = generationIndicator + 1;
    
    y0 = [P0, D0];
    generationCounter = 0;
    
    
    fprintf('\n\tGeneration %d:\n',generationCounter);
    fprintf('\tt\t=\t%0.4f,\tP\t=\t%0.4f,\tD\t=\t%0.4f\n\n\n',time(end),P(end),D(end));    
    
    % Plot the two solutions
    plot(time,P,'blue')
    hold on
    plot(time,D,'red')
    hold on
    
    % Print to file for nice plotting
    for index = 1:length(time)
        fprintf(intactFile,'%0.3f\t%0.3f\n',time(index),P(index));
        fprintf(damageFile,'%0.3f\t%0.3f\n',time(index),D(index));        
    end
    
    
    %%
    %
    while damageValue<1
        if generationCounter>infiniteGenerations
            break;
        end
        %[t,y] = ode45(@(t,y) odefcn(t,y,k,g,Q,mu), tspan, y0);
        [t,y] = ode45(@(t,y) odefcn(t,y,k,g,Q), tspan, y0);
        n = length(t);
        [time, P, D] = homeMadeInterpolator(t,y);
        
        damageValue = D(end);
        
        %damageThreshold = s*damageValue;
        
        tTot = tTot + time(end);
        
        %[P0,D0] = cellDivision(s,re,dynInd,damageValue,Q,generationIndicator);
        [P0,D0] = cellDivision(s,re,damageValue,Q,generationIndicator);        
        y0 = [P0, D0];
        generationCounter = generationCounter + 1;
        time = time + (tTot - time(end)).*ones(length(time),1);
        
        fprintf('\n\tGeneration %d:\n',generationCounter);
        fprintf('\tt\t=\t%0.4f,\tP\t=\t%0.4f,\tD\t=\t%0.4f\n\n\n',time(end),P(end),D(end));            
        
        % Plot the two solutions
        plot(time,P,'blue')
        hold on
        plot(time,D,'red')
        hold on
        
        % Print to file for nice plotting
        for index = 1:length(time)
            fprintf(intactFile,'%0.3f\t%0.3f\n',time(index),P(index));
            fprintf(damageFile,'%0.3f\t%0.3f\n',time(index),D(index));            
        end
    end
    %
    %
    %
    %
    if generationCounter>infiniteGenerations
        fprintf('\n\t\tWe never died with (k1,k2)=(%0.6f,%0.6f)!\n\n',k(1),k(2));
    else
        fprintf('\n\n\t\t(k1,k2)=(%0.6f,%0.6f) resulted in %d divisions\n\n',k(1),k(2),generationCounter);
        fprintf('\t\tand it took t\t=\t%0.5f time units!\n\n',tTot);
    end
    
    
    grid on
    xlabel('Time, $\tau$','Fontsize',30,'interpreter','latex')
    ylabel('Proportion of proteins','Fontsize',30,'interpreter','latex')
    tit = title(...
        {['\textbf{Simulation with parameters}: $\left(k_{1},k_{2}\right)=\left('...
        ,num2str(k(1)),',',num2str(k(2)),'\right)$'],
        ['\textit{Generations=$\mathit{',num2str(generationCounter),'}$}']}...
        );
    set(tit,'Fontsize',50,'interpreter','latex')
    axis([0,time(end),0,1])
    leg = legend('Intact proteins, $\frac{P}{P_{\mathrm{div}}}$','Damage, $\frac{D}{D_{\mathrm{death}}}$');
    set(leg,'Location','SouthEast','Fontsize',30,'interpreter','latex')
    ax = gca;
    set(ax,'Ticklabelinterpreter','latex','Fontsize',30)
    
    

    
else
    generationCounter = 0;
    plot(t,y(:,1),'blue')
    hold on
    plot(t,y(:,2),'red')
    hold on
    
    
    % Print to file for nice plotting
    for index = 1:length(t)
        fprintf(intactFile,'%0.3f\t%0.3f\n',t(index),y(index,1));
        fprintf(damageFile,'%0.3f\t%0.3f\n',t(index),y(index,2));        
    end
    grid on
    xlabel('Time, $\tau$','Fontsize',30,'interpreter','latex')
    ylabel('Proportion of proteins','Fontsize',30,'interpreter','latex')
    tit = title(...
        {['\textbf{Simulation with parameters}: $\left(k_{1},k_{2}\right)=\left('...
        ,num2str(k(1)),',',num2str(k(2)),'\right)$'],
        ['\textit{Generations=$\mathit{',num2str(generationCounter),'}\Longrightarrow$ Premature Death}']}...
        );
    set(tit,'Fontsize',50,'interpreter','latex')
    axis([0,6,0,1])
    leg = legend('Intact proteins, $\frac{P}{P_{\mathrm{div}}}$','Damage, $\frac{D}{D_{\mathrm{death}}}$');
    set(leg,'Location','SouthEast','Fontsize',30,'interpreter','latex')
    ax = gca;
    set(ax,'Ticklabelinterpreter','latex','Fontsize',30)
    
    
    fprintf('\n\t\tPremature death hey?!\n\n\n');
end


%print(fig, '-depsc', '-r100', '20180124Case4PrematureDeath.eps')    

% Close both files
fclose(intactFile);
fclose(damageFile);


