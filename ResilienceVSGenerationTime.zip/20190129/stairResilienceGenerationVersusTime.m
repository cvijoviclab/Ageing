%% We write a program to graphically represent the RLS and generation time
% Load the time in the first column and the RLS in the second
dataIntact = load('P.txt');
% Save the intact proteins
intact = dataIntact(:,2);
% Save the time variable
time = dataIntact(:,1);
% Find out where division occurs
[r,c] = find(intact==1);
% We find the RLS
RLS = (0:length(r))';
% We find the generation time
time = [0;time(r,1)];
% We allocate two results vectors twice as long
RLSres = zeros(2*length(r),1);
genTime = zeros(2*length(r),1);
% Define a helpIndex
helpIndex = 1;
% Loop through and define our new vectors
for index = 1:length(r)
   RLSres(helpIndex,1) = RLS(index,1);
   genTime(helpIndex,1) = time(index,1);
   helpIndex = helpIndex + 1;
    if index<length(r)
        RLSres(helpIndex,1) = RLS(index,1);
        genTime(helpIndex,1) = time(index+1,1);
   else
        RLSres(helpIndex,1) = RLS(index,1);
        genTime(helpIndex,1) = 500;       
   end
   helpIndex = helpIndex + 1;
end



fileID = fopen('stairsQHigh.txt','w'); 
fprintf(fileID,'t\tRLS\n');
for index = 1:length(RLSres)
    fprintf(fileID,'%0.3f\t%d\n',genTime(index,1),RLSres(index,1));
end
fclose(fileID);
