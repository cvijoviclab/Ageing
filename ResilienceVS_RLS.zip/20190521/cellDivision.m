function [P0,D0] = cellDivision(s,re,DamOrg,Q,generationIndicator)
%% Constants for DC
% Date: 2019-01-29
% Written by: Johannes Borgqvist
% Description:
% Given the size proportion s, the retention coefficient
% re, the resilience parameter Q and the generationIndicator
%(1 for daughter & 0 for mother) the function returns
% the initial conditions [P0,D0].
%% Initial conditions
%----------------------------------------------------------
% Initialise the intact and damage hey?
% We have a daughter cell
if generationIndicator == 1
    P0 = (1-s)+re*(1-s)*Q*DamOrg;% Intact daughter
    D0 = (1-s)*(1-re)*DamOrg; % Damage daughter
else % For the rest of her life, she is a mother...
    P0 = s - re*(1-s)*Q*DamOrg; % Intact mother
    D0 = (s + ((1-s)*re))*DamOrg; % Damage mother
end
end