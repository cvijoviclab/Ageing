function dydt = cleggModel(t,y,theta,Q)
% Date: 2019-01-05
% Written by: Johannes Borgqvist
% Description: 
% The function defines the system of ODEs that
% is to be solved for the tetragon Model
%% Define the involved paramaters in the tetragon model
% Proportion in the growth term
beta = theta(1); 
% Damage formation, k1
k1 = theta(2);
% Repair and degradation, k2
k2 = theta(3);
% Repair in damage equation
k3 = theta(4);
%% Actual ODE solving
% Nonlinear factor
factor1 = ( ( y(1) ) / ( ( y(1) ) + ( Q * y(2) ) ) );
factor2 = ( ( y(1) ) / ( ( beta * y(1) ) + ( Q * y(2) ) ) );
%factor1 = factor2;
% Allocate memory for the two solutions "y = [P; D]"
dydt = zeros(2,1);
% State 1: the intact proteins P
dydt(1) = ( ( 1 - beta ) * y(1) * factor1 ) - ( k1 * y(1) ) + ( k2 * y(2) * factor2 ); 
% State 2: the damage D
dydt(2) = ( ( k1 / Q ) * y(1) ) - ( k3 * y(2) * factor2 );
end
