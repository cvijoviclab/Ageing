%% %% In silico experiments with RLS
% Date: 2019-05-21
% Written by: Johannes Borgqvist
% Description: 
% Using the two models we simulate the RLS and the generation time
% for a bunch of cells with different spread in the resilience parameter
% in order to see how the resulting generation time and RLS distributions
% look like

%% (0.) Setting up everything
% Tidy up to get a nice work space
clear,clc;
%-----------------------------------------------------------
% We have the setup variables stored in the variable 
% called "GeneralData.mat". So, we load it!
data = load('GeneralData.mat');
% We save the division threshold, Pdiv
Pdiv = data.Pdiv;
% We save the resilience quotient, Q for five different cells
temp = load('QForFiveCells.mat');
QVec = temp.QVec;
% We fit a normal distribution to the QVec
pd = fitdist(QVec,'Normal');
QMean = pd.mu;
varQ = pd.sigma;
Q = 2.55;
% We save the size proportion, s
s = data.sAvg;
%s = round(data.sAvg,2);
% Now, we calculate the retention coefficient with our magic formula
% Retention coefficient 
re = ( 1 / Q ) * ( ( ( 2 * s ) - 1 ) / ( 1 - s ) );
% We use the value for the growth rate measured by Snoep et al.
mu = 0.5;
%% Simulate with our model
% We take the growth factor g
g = 1.05;
% Damage formation and repair
%blanks(5);
%k1 = input('What is the damage formation rate, k1?\n');
k1 = 0.5108;
%blanks(5);
%k2 = input('What is the damage repair rate, k2?\n');
k2 = 0.15;
k = [k1; k2];
% Ok, we gather all rate parameters in a parameter vector
thetaOurModel = [g; k1; k2];
%% Simulate with Clegg's model

% The growth percentage
beta = 0.05;
% Damage formation and repair for Clegg
%blanks(5);
k1Clegg = 0.32;
%blanks(5);
%k3Clegg = 0.15;
% The second paramater is slightly bigger than the third according to
% Cleggs modelling assumptions
%k2Clegg = 1.25 * k3Clegg;
k2Clegg = 0.6;
% We save all the start parameters in the vector, hey? 
thetaCleggsModel = [beta; k1Clegg; k2Clegg; mu]; % The start guess factor

%modelIndicator = 2;
%QTemp = Q;
%reTemp = re;
% We simulate the replicative life span for our model
%[RLSClegg,generationTimeClegg] = generationCounter(thetaCleggsModel,QTemp,reTemp,s,modelIndicator);

%RLSClegg



%% Simulate with Erjavecs model

alpha = 2;
Km = 0.1;
k1 = 1.0;
k2 = 0.45;
k3 = 0.05;


thetaErjavecsModel = [alpha;Km;k1;k2;k3];


modelIndicator = 3;
QTemp = Q;
reTemp = re;
% We simulate the replicative life span for our model
[RLSErjavec,generationTimeErjavec] = generationCounter(thetaErjavecsModel,QTemp,reTemp,s,modelIndicator);
RLSErjavec
% tspan = [0 100];
% %RLSErjavec
% DamOrg = 0;
% daughterNotMother = 1; % Daughter indicator
% %[P0,D0] = cellDivision(s,re,dynInd,DamOrg,Q,daughterNotMother);
% [P0,D0] = cellDivision(s,re,DamOrg,Q,daughterNotMother);
% % Gather Initial conditions in a vector "y0"
% y0 = [P0; D0];
% [t,y] = ode45(@(t,y) erjavecModel(t,y,theta,Q), tspan, y0);   
% [t1, P1, D1] = homeMadeInterpolator(t,y);
% D2 = D1;
% daughterNotMother = 0; % Mother indicator
% nuOfGen = 2;
% for index = 1:nuOfGen
%     DamOrg = D2(end);
%     [P0,D0] = cellDivision(s,re,DamOrg,Q,daughterNotMother);
%     y0 = [P0; D0];
%     % Solve the ODE with the given parameters and initial conditions
%     [t,y] = ode45(@(t,y) erjavecModel(t,y,theta,Q), tspan, y0);  
%     [t2, P2, D2] = homeMadeInterpolator(t,y);
% end
% 
% figure(1)
% clf
% subplot(1,2,1)
% plot(t1,P1,'b',t1,D1,'r')
% grid on
% title('Division 1')
% subplot(1,2,2)
% plot(t2,P2,'b',t2,D2,'r')
% grid on
% title(['Division ',num2str(nuOfGen)])


%% The different damage resilience values, Q that we test.
%Q_test = [2.50:0.01:2.60];
nuParam = 100;
Q_test = linspace(2.40,2.60,nuParam);

fprintf('======================================================================================\n\n');
fprintf('\t COMPARISONS BETWEEN OUR AND CLEGGS MODEL!\n\n');
fprintf('======================================================================================\n\n');
fprintf('\t\tOur\t\tClegg\t\tErjavec\n');
fprintf('\t\t(R,Q)\t\t(R,Q)\t\t(R,Q)\n\n');
% We save this dependence 
fileClegg = fopen('./Plotting/RLSvsQCleggModel.txt','w'); 
fprintf(fileClegg,'Q\tR\n');
fileOur = fopen('./Plotting/RLSvsQOurModel.txt','w'); 
fprintf(fileOur,'Q\tR\n');
fileErjavec = fopen('./Plotting/RLSvsQErjavecModel.txt','w'); 
fprintf(fileErjavec,'Q\tR\n');
for i = 1:length(Q_test)
    reTemp = ( 1 / Q ) * ( ( ( 2 * s ) - 1 ) / ( 1 - s ) );    
    QTemp = Q_test(i);
    % We want to simulate model 1, hey?
    modelIndicator = 1;
    % We simulate the replicative life span for our model
    [RLSOur,generationTimeOur] = generationCounter(thetaOurModel,QTemp,reTemp,s,modelIndicator);    
    % We change to study Clegg's model
    modelIndicator = 2;
    % We simulate the replicative life span for Cleggs model
    [RLSClegg,generationTimeClegg] = generationCounter(thetaCleggsModel,QTemp,reTemp,s,modelIndicator);
    % We change to study Erjavec's model
    modelIndicator = 3;
    % We simulate the replicative life span for Erjavec's model    
    [RLSErjavec,generationTimeErjavec] = generationCounter(thetaErjavecsModel,QTemp,reTemp,s,modelIndicator);    
    %fprintf('--------------------------------------------------------\n');
    %Print the replicative life span
    %Our model
    fprintf('\t\t(%d,%2.3f)',RLSOur,QTemp);    
    fprintf(fileOur,'%0.3f\t%d\n',QTemp,RLSOur);    
    %Clegg model
    fprintf('\t(%d,%2.3f)',RLSClegg,QTemp);
    fprintf(fileClegg,'%1.3f\t%d\n',QTemp,RLSClegg);        
    % Erjavec model
    fprintf('\t(%d,%2.3f)\n\n',RLSClegg,QTemp);
    fprintf(fileErjavec,'%1.3f\t%d\n',QTemp,RLSErjavec);            
    fprintf('------------------------------------------------------------------\n');
end


fclose(fileOur);
fclose(fileClegg);
fclose(fileErjavec);
fprintf('======================================================================================\n\n');
% 
% 
% 
