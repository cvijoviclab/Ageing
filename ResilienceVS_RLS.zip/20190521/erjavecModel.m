function dydt = erjavecModel(t,y,theta,Q)
% Date: 2019-01-05
% Written by: Johannes Borgqvist
% Description: 
% The function defines the system of ODEs that
% is to be solved for the tetragon Model. This is the Erjavec model!
%% Define the involved paramaters in the tetragon model
% The growth factor, alpha
alpha = theta(1); 
% Monod coefficient, Km
Km = theta(2);
% Degradation rate of intact proteins, k1
k1 = theta(3);
% Damage formation rate, k2
k2 = theta(4);
% Degradation rate of damage, k3
k3 = theta(5);
%% Actual ODE solving
% Allocate memory for the two solutions "y = [P; D]"
dydt = zeros(2,1);
% State 1: the intact proteins P
dydt(1) = ( alpha * ( ( y(1) ) / ( Km + y(1) + y(2) ) ) ) - ( k1 * y(1) ); 
% State 2: the damage D
dydt(2) = ( ( (k2) / (Q) ) * y(1) ) - ( k3 * y(2) );
end