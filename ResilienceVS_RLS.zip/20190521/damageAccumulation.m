function dydt = damageAccumulation(t,y,k,g,Q)
% %% Defining parameters
% Program for simulating the tetragon model. We take in the rate parameters
% k1, k2 (which are stored in the vector k) and also the growth term g
% together with the resilience quotient Q. Then we return the time variable
% t and the two states (P and D) which are stored in the function value
% y.
%% Actual ODE solving
% Allocate memory for the two states
dydt = zeros(2,1);
% Intact proteins P stored as y1
dydt(1) = (y(1) * (g - y(2)) ) - (k(1) * y(1)) + (k(2) * Q * y(2)); 
% Intact proteins D stored as y2
dydt(2) = ( (k(1)/Q) * y(1)) - (k(2) * y(2));
end