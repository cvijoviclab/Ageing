function [RLS,generationTime] = generationCounter(theta,Q,re,s,modelIndicator)
%% Entire life span for a single cell
% Date: 2018-03-13
% Written by: Johannes Borgqvist
% Description:
% Given the size proportion s, the retention coefficient
% re, the dynInd variable (1 for dynamic & 0 for static)
% the resilience parameter Q, the cell growth factor g,
% the cell growth mu, the damage formation rate k1
% and the damage repair rate k2 the function returns
% the Replicative Life Span (RLS) which an integer and
% a vector containing all generation times.
%% Initialisation
% Allocate memory for the "generation time"
generationTime = [];
% Define infinite generations, i.e.
% if "RLS >infinite generations" we break
infGen = 100;
% Define the Replicative Life Span
RLS = 0;
if modelIndicator == 1
    % Change the notation of the parameters
    g = theta(1);
    k1 = theta(2);
    k2 = theta(3);
    % Gather rate parameters in a vector "k"
    k = [k1; k2];
end
% Define the time span for the ODE
tspan = [0 100];
% Damage of the original cell
%DamOrg = rand();
DamOrg = 0;
%% Simulation of entire RLS
% Initial conditions of daughter given
% by the function "cellDivision"
daughterNotMother = 1; % Daughter indicator
%[P0,D0] = cellDivision(s,re,dynInd,DamOrg,Q,daughterNotMother);
[P0,D0] = cellDivision(s,re,DamOrg,Q,daughterNotMother);
% Gather Initial conditions in a vector "y0"
y0 = [P0; D0];
if modelIndicator ==1
    % Solve the ODE with the given parameters and initial conditions
    [t,y] = ode45(@(t,y) damageAccumulation(t,y,k,g,Q), tspan, y0);
elseif modelIndicator == 2
    % Solve the ODE with the given parameters and initial conditions
    [t,y] = ode45(@(t,y) cleggModel(t,y,theta,Q), tspan, y0);
elseif modelIndicator == 3
    % Solve the ODE with the given parameters and initial conditions
    [t,y] = ode45(@(t,y) erjavecModel(t,y,theta,Q), tspan, y0);    
end
% Interpolate until final value
[time, P, D] = homeMadeInterpolator(t,y);
% Save the "DamOrg"
DamOrg = D(end);
if DamOrg > 1
    %RLS = 0;
    generationTime = 0;
else
    % Save the generationTime for the daughter
    %generationTime = [generationTime; time(end)];
    % Increase the RLS
    %RLS = RLS + 1;
    % From now on we are a Mother
    daughterNotMother = 0; % Mother indicator
    % We loop until we die!
    while DamOrg<1
        % We make sure to break if
        % our RLS becomes to high
        if RLS>infGen
            RLS = 600;
            break;
        end
        %================================================
        % Otherwise we redo the whole thingy!
        % Initial conditions of daughter given
        % by the function "cellDivision"
        [P0,D0] = cellDivision(s,re,DamOrg,Q,daughterNotMother);
        % Gather Initial conditions in a vector "y0"
        y0 = [P0; D0];
        if modelIndicator ==1
            % Solve the ODE with the given parameters and initial conditions
            [t,y] = ode45(@(t,y) damageAccumulation(t,y,k,g,Q), tspan, y0);
        elseif modelIndicator == 2
            % Solve the ODE with the given parameters and initial conditions
            [t,y] = ode45(@(t,y) cleggModel(t,y,theta,Q), tspan, y0);
        elseif modelIndicator == 3
            % Solve the ODE with the given parameters and initial conditions
            [t,y] = ode45(@(t,y) erjavecModel(t,y,theta,Q), tspan, y0);  
        end
        % Interpolate until final value
        [time, P, D] = homeMadeInterpolator(t,y);
        % Save the "DamOrg"
        DamOrg = D(end);
        % Save the generationTime
        generationTime = [generationTime; time(end)];
        % Increase the RLS
        RLS = RLS + 1;
        %================================================
    end
    
end
end
